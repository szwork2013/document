-------------------------------------------------------------------------------

|  We are currently looking for contributors for SASS files. If you are       |
|  interested to help and contribute to the SmartAdmin community by           |
|  giving us your versions of SASS files for SmartAdmin please contact        |
|  us via email (info@myorange.ca). All your contributions will be            |
|  credited and referenced. Please help us continue the growth of SmartAdmin  |

-------------------------------------------------------------------------------